import { Component, OnInit } from '@angular/core';
import {Songs} from '../Songs';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  songs:any;
  selectedSong:any;
  constructor() { }

  ngOnInit(): void {
    this.songs=Songs;
    this.selectedSong=this.songs[0];
  }

  displaySong(song){
    this.selectedSong=song;
  }

}
