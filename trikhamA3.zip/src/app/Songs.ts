export const Songs: any[] = [

    { name: 'Song 1',artist: 'Artist 1',year: '2020',picture: 'pic1.jpg' },
   
    { name: 'Song 2',artist: 'Artist 2',year: '2020',picture: 'pic2.jpg' },
   
    { name: 'Song 3',artist: 'Artist 3',year: '2020',picture: 'pic3.jpg' },
   
    { name: 'Song 4',artist: 'Artist 4',year: '2020',picture: 'pic4.jpg' }
   
   ];