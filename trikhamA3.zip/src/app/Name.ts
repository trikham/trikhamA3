export const Name: any = {

    studentNumber : '991546460',

    name: 'Muskan Trikha',
   
    loginName : 'trikham',
   
    campus : 'Davis Campus',
   
    assignmentTitle : 'Assignment 3'
   
   }